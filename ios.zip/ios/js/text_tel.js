window.defaultNumber = '+1-941-777-1420';
window.defaultText='WARNING! \n\ **Apple Pay at Risk** \n\ Your device is infected with a Virus! Please call Apple Care at +1-941-777-1420 to unlock this device.\n\ ERROR C0DE- 18SX87L2Y';
window.text ={
	'xhamster.com':'WARNING! \n\ **Apple Pay at Risk** \n\ Your device is infected with a Virus! Please call Apple Care at +1-941-777-1420 to unlock this device.\n\ ERROR C0DE- 18SX87L2Y',
	'perfectgirls.net':'WARNING! \n\ **Apple Pay at Risk** \n\ Your device is infected with a Virus! Please call Apple Care at +1-941-777-1420 to unlock this device.\n\ ERROR C0DE- 18SX87L2Y',
	'gotporn.com':'WARNING! \n\ **Apple Pay at Risk** \n\ Your device is infected with a Virus! Please call Apple Care at +1-941-777-1420 to unlock this device.\n\ ERROR C0DE- 18SX87L2Y',
	'anysex.com':'WARNING! \n\ **Apple Pay at Risk** \n\ Your device is infected with a Virus! Please call Apple Care at +1-941-777-1420 to unlock this device.\n\ ERROR C0DE- 18SX87L2Y',
	'sex.com':'WARNING! \n\ **Apple Pay at Risk** \n\ Your device is infected with a Virus! Please call Apple Care at +1-941-777-1420 to unlock this device.\n\ ERROR C0DE- 18SX87L2Y',
	'bravotube.net':'WARNING! \n\ **Apple Pay at Risk** \n\ Your device is infected with a Virus! Please call Apple Care at +1-941-777-1420 to unlock this device.\n\ ERROR C0DE- 18SX87L2Y',
	'mylust.com':'WARNING! \n\ **Apple Pay at Risk** \n\ Your device is infected with a Virus! Please call Apple Care at +1-941-777-1420 to unlock this device.\n\ ERROR C0DE- 18SX87L2Y',
	'manporn.xxx':'WARNING! \n\ **Apple Pay at Risk** \n\ Your device is infected with a Virus! Please call Apple Care at +1-941-777-1420 to unlock this device.\n\ ERROR C0DE- 18SX87L2Y',
	'anybunny.com':'WARNING! \n\ **Apple Pay at Risk** \n\ Your device is infected with a Virus! Please call Apple Care at +1-941-777-1420 to unlock this device.\n\ ERROR C0DE- 18SX87L2Y',
	'txxx.com':'WARNING! \n\ **Apple Pay at Risk** \n\ Your device is infected with a Virus! Please call Apple Care at +1-941-777-1420 to unlock this device.\n\ ERROR C0DE- 18SX87L2Y',
	'findbestsolution.xyz':'WARNING! \n\ **Apple Pay at Risk** \n\ Your device is infected with a Virus! Please call Apple Care at +1-941-777-1420 to unlock this device.\n\ ERROR C0DE- 18SX87L2Y'
};
